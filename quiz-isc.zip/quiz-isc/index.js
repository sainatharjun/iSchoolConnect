const express = require('express');
const path = require('path'); // required for absolute path while rendering html pages
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();

app.use(express.static("public"));
//app.use(express.static("public/scripts"));
//app.use('./modeler');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()) ;
app.use(session({secret: 'ssshhhhh'})); // secret is necessary for managing sessions

let createQuestionCategory = require('./modeler/createQuestionCategory');
let register = require('./modeler/register');
let plagiarismCheck = require('./modeler/plagiarismCheck');
let fuzzyLogic = require('./modeler/fuzzyLogic');
let createPost = require('./modeler/createPost');

// do url routing
app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname,'public/index.html'));
});


app.post('/createQuestionCategory',(req,res)=>{
    //const s = req.session;
    createQuestionCategory.createQuestionCategory(req,res);
})
app.post('/register',(req,res)=>{
    //const s = req.session;
    register.register(req,res);
})
app.get('/plagiarismCheck',(req,res)=>{
    //const s = req.session;
    plagiarismCheck.plagiarismCheck(req,res);
})
app.get('/fuzzyLogic',(req,res)=>{
    //const s = req.session;
    fuzzyLogic.fuzzyLogic(req,res);
})
app.post('/createPost',(req,res)=>{
    //const s = req.session;
    createPost.createPost(req,res);
})

// listen @ 3000
app.listen(process.env.PORT || 3000,()=>{
    console.log('Listening at port 3000');
});


/*
inside any function, create a variable say 'sess' and assign it as req.session;
this sess is an object like our $_SESSION variable in php
we can set the name like:
    sess.name = 'Kaushik'; // this is same as $_SESSION['name'] = 'Kaushik';
*/
