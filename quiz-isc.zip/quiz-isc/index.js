const express = require('express');
const path = require('path'); // required for absolute path while rendering html pages
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();

app.use(express.static("views"));
app.set('view engine', 'ejs');
app.use(express.urlencoded( {extended : true} ));
app.locals.pretty = true;
//app.use(express.static("public/scripts"));
//app.use('./modeler');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()) ;
app.use(session({secret: 'ssshhhhh'})); // secret is necessary for managing sessions

let login = require('./modeler/login');
let register = require('./modeler/register');
let createQuestionCategory = require('./modeler/createQuestionCategory');
let getQuizCategories = require('./modeler/getQuizCategories');
let getQuestionCategories = require('./modeler/getQuestionCategories');
let createQuestion = require('./modeler/createQuestion');
let getQuestions = require('./modeler/getQuestions');
let submitReport = require('./modeler/submitReport');

;
// do url routing
app.get('/',(req,res)=>{
    getQuizCategories.getQuizCategories(req,res);
});

app.post('/login',(req,res)=>{
    //const s = req.session;
    login.login(req,res);
})

app.post('/register',(req,res)=>{
    //const s = req.session;
    register.register(req,res);
})

app.post('/createQuestionCategory',(req,res)=>{
    //const s = req.session;
    createQuestionCategory.createQuestionCategory(req,res);
})

app.post('/getQuestions',(req,res)=>{
    //const s = req.session;
    getQuestions.getQuestions(req,res);
})
app.post('/submitReport',(req,res)=>{
    //const s = req.session;
    submitReport.submitReport(req,res);
})

app.post('/createQuestion',(req,res)=>{
    //const s = req.session;
    createQuestion.createQuestion(req,res);
})

app.get('/getQuestionCategories',(req,res)=>{
    //const s = req.session;
    req.session.qArray=getQuestionCategories.getQuestionCategories(req,res);
})

app.get('/quiz',(req,res)=>{
    console.log(req.qArray)
    // res.render('quiz.ejs',{qArray})
})



// listen @ 3000
app.listen(process.env.PORT || 3000,()=>{
    console.log('Listening at port 3000');
});


/*
inside any function, create a variable say 'sess' and assign it as req.session;
this sess is an object like our $_SESSION variable in php
we can set the name like:
    sess.name = 'Kaushik'; // this is same as $_SESSION['name'] = 'Kaushik';
*/
