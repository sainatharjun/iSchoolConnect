//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";



module.exports.login = (req,res) => {
   
       
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, db) {
            if (err) throw err;
            
            // db.close();
            var dbo = db.db("iSchoolConnect");
            query={email:req.body.email}
            dbo.collection("Users").find(query).toArray(function(err, result) {
                if (err) throw err;
                if(result.length){
                  
                  req.session.user=result[0];
                  //console.log(req.session.user)
                  res.send(['success',result[0].username]);
                }
                else{
                  res.send('failed');
                }
              });
          });



}