//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";





module.exports.getQuestionCategories = (req,res) => {
var categories=[]
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
            if (err) throw err;
            // db.close();
            var dbo = db.db("iSchoolConnect");
            await dbo.collection("QuestionCategories").find({}).toArray(function(err, resArr) {
              console.log('in')
              if (err) 
              {console.log(err) ;
              flag=1
              }
              else{
                console.log('Documents Found')
                resArr.forEach(el => {
                  categories.push(el.categoryName)
                });
                res.render('adminDashboard.ejs',{categories:categories})
              }              
            });
              });
          };



