//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";





module.exports.getQuestions = (req,res) => {
var result;
var categories=[]
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
            if (err) throw err;
            // db.close();
            var dbo = db.db("iSchoolConnect");
            await dbo.collection("Questions").find(req.body).toArray(function(err, resArr) {
              if (err) 
              {console.log(err) ;
              flag=1
              }
              else{
                resArr.forEach(el => {
                  categories.push(el.categoryName)
                });   


                res.send(resArr)
                // console.log(req.session.questions)
              }              
            });
              });
          };



