//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";



module.exports.submitReport = (req,res) => {
   
       
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, db) {
            if (err) throw err;
            
            // db.close();
            var dbo = db.db("iSchoolConnect");
            query={username:req.body.username}
            var set={$set:{score: parseInt( req.body.score),report:req.body.report}}
            dbo.collection("Users").updateOne(query,set,function(err, result) {
                if (err) throw err;
                if(result.length){
                  //console.log(req.session.user)
                  res.send('success');
                }
                else{
                  res.send('failed');
                }
              });
          });



}