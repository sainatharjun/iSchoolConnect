//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";





module.exports.createQuestion = (req,res) => {
  var flag=0;

       
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
            if (err) throw err;
            // db.close();
            var dbo = db.db("iSchoolConnect");
            await dbo.collection("Questions").insertOne(req.body, function(err, result) {
              if (err) 
              {console.log(err) ;
               res.send('Not OK')
              }
              else{
                console.log('Question Created', result)
                res.send('OK')

              }              
            });
        });
};



