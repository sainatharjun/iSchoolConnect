//var con = require('./db_connection');
const { MongoClient } = require('mongodb');
const url = "mongodb+srv://sainatharjun:saisai71@cluster0.zroar.mongodb.net/iSchoolConnect?retryWrites=true&w=majority";





module.exports.createQuestionCategory = (req,res) => {
  var flag=0;

       
        MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, async function(err, db) {
            if (err) throw err;
            // db.close();
            var dbo = db.db("iSchoolConnect");
            await dbo.collection("QuestionCategories").insertOne(req.body, function(err, res) {
              if (err) 
              {console.log(err) ;
              flag=1
              }
              else{
                console.log('Category Inserted')
                flag=0
              }              
            });
              });

              if(flag==0){
                res.send('OK')
              }
              else{
                res.send('Not OK')
              }
          };



